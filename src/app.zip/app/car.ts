export interface Car{
    id:number,
    carnumber:string,
    time:string
    occupied:boolean
}
